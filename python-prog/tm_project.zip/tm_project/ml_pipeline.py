from kfp import dsl
from kfp.v2 import compiler

# Import components from the other files
from my_components.load_component import load_data
from my_components.preprocess_component import preprocess_data
from my_components.train_model_component import train_model
from my_components.evaluate_component import evaluate_model

@dsl.pipeline(
    name="modular-iris-pipeline",
    description="A modular pipeline example."
)
def ml_pipeline():
    # 1. Load Data
    load_task = load_data()

    # 2. Preprocess Data (Input comes from Load Data output)
    preprocess_task = preprocess_data(
        input_dataset=load_task.outputs["output_dataset"]
    )

    # 3. Train Model (Input comes from Preprocess output)
    train_task = train_model(
        input_dataset=preprocess_task.outputs["output_dataset"]
    )

    # 4. Evaluate (Takes Preprocessed Data and Trained Model)
    evaluate_task = evaluate_model(
        input_dataset=preprocess_task.outputs["output_dataset"],
        model_input=train_task.outputs["output_model"]
    )

if __name__ == "__main__":
    compiler.Compiler().compile(
        pipeline_func=ml_pipeline,
        package_path="pipeline.json"
    )
    print("Success! pipeline.json generated.")