from kfp.v2 import dsl
from kfp.v2.dsl import Input, Output, Dataset, Model, Metrics
from typing import NamedTuple

@dsl.component(
    base_image="python:3.9",
    packages_to_install=["pandas", "scikit-learn", "joblib"]
)
def evaluate_model(
    input_dataset: Input[Dataset], 
    model_input: Input[Model],
    metrics: Output[Metrics]
) -> NamedTuple("EvaluationOutput", [("accuracy", float)]):
    import pandas as pd
    import joblib
    from sklearn.metrics import accuracy_score

    df = pd.read_csv(input_dataset.path)
    model = joblib.load(model_input.path)

    X = df.drop(columns=["target"])
    y = df["target"]

    preds = model.predict(X)
    acc = accuracy_score(y, preds)

    print(f"Accuracy: {acc}")
    
    metrics.log_metric("accuracy", acc)
    
    return (acc,)