from kfp.v2 import dsl
from kfp.v2.dsl import Input, Output, Dataset

@dsl.component(
    base_image="python:3.9",
    packages_to_install=["pandas", "scikit-learn"]
)
def preprocess_data(
    input_dataset: Input[Dataset], 
    output_dataset: Output[Dataset]
):
    import pandas as pd
    from sklearn.preprocessing import StandardScaler

    df = pd.read_csv(input_dataset.path)
    
    features = df.drop(columns=["target"])
    scaled = StandardScaler().fit_transform(features)
    
    df_scaled = pd.DataFrame(scaled, columns=features.columns)
    df_scaled['target'] = df['target']
    
    df_scaled.to_csv(output_dataset.path, index=False)