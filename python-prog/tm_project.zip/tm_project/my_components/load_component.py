from kfp.v2 import dsl
from kfp.v2.dsl import Output, Dataset

@dsl.component(
    base_image="python:3.9",
    packages_to_install=["pandas", "scikit-learn"]
)
def load_data(output_dataset: Output[Dataset]):
    import pandas as pd
    from sklearn.datasets import load_iris

    df = load_iris(as_frame=True).frame
    
    df.to_csv(output_dataset.path, index=False)