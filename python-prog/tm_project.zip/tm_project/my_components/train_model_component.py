from kfp.v2 import dsl
from kfp.v2.dsl import Input, Output, Dataset, Model

@dsl.component(
    base_image="python:3.9",
    packages_to_install=["pandas", "scikit-learn", "joblib"]
)
def train_model(
    input_dataset: Input[Dataset], 
    output_model: Output[Model]
):
    import pandas as pd
    from sklearn.linear_model import LogisticRegression
    import joblib

    df = pd.read_csv(input_dataset.path)
    X = df.drop(columns=["target"])
    y = df["target"]

    model = LogisticRegression()
    model.fit(X, y)

    joblib.dump(model, output_model.path)