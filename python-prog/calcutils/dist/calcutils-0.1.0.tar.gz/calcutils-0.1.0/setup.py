from setuptools import setup, find_packages 



setup(
    name = "calcutils", 
    version = "0.1.0", 
    description = "A simple calculation utility package", 
    author = "Rushikesh", 
    packages = find_packages(), 
    install_requires=[], 
)